const RULE_ID_HEADERS = 1001;
const RULE_ID_TRACKER_BLOCK_START = 2000;

const UA_HEADER_VALUES = {
  "windows-chrome":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
  "mac-chrome":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
  "linux-chrome":
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
};

// Известные антифрод / device-fingerprinting сервисы + отдельные
// IP-geolocation / timezone-детекторы, которые сторонние виджеты на сайтах
// используют, чтобы узнать ваше реальное местоположение и часовой пояс
// в обход подмены на уровне JS.
//
// ВАЖНО: сюда никогда не добавляем "ipwho.is" — это сервис, который САМО
// расширение использует для функции автонастройки часового пояса (см.
// detectTimezoneOnce ниже и popup.js). Если добавить его в этот список,
// declarativeNetRequest заблокирует и наш собственный запрос тоже —
// именно так раньше был незаметно сломан ipapi.co, стоявший одновременно
// и в фиче автонастройки, и в блок-листе.
const TRACKER_DOMAINS = [
  // антифрод / device fingerprinting
  "fingerprintjs.com", "fpjs.io", "fingerprint.com", "threatmetrix.com",
  "iovation.com", "forter.com", "riskified.com", "sift.com", "seon.io",
  "perimeterx.com", "datadome.co", "distilnetworks.com", "maxmind.com",
  "clientjs.org",
  // ip-geolocation / timezone виджеты, встраиваемые сторонними сайтами
  "ipapi.co", "ip-api.com", "ipinfo.io", "ipgeolocation.io", "geojs.io",
  "freegeoip.app", "extreme-ip-lookup.com", "ipwhois.io", "db-ip.com",
  "worldtimeapi.org", "ipdata.co", "abstractapi.com",
];

const DEFAULTS = {
  enabled: true,
  uaPreset: "windows-chrome",
  canvasNoise: true,
  canvasAdaptive: true,
  webglSpoof: true,
  timezoneSpoof: false,
  timezone: "Europe/London",
  webrtcProtection: true,
  webrtcWhitelist: [],
  hardwareSpoof: true,
  fingerprintSeed: "default-seed",
  siteExceptions: [],
  blockTrackers: true,
};

// --- Заголовки (User-Agent) ---
async function applyHeaderRules(settings) {
  const uaValue = UA_HEADER_VALUES[settings.uaPreset] || UA_HEADER_VALUES["windows-chrome"];
  const requestHeaders = [{ header: "User-Agent", operation: "set", value: uaValue }];

  if (!settings.enabled) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [RULE_ID_HEADERS] });
    return;
  }

  const condition = {
    urlFilter: "*",
    resourceTypes: [
      "main_frame", "sub_frame", "xmlhttprequest", "script",
      "image", "font", "media", "websocket", "other",
    ],
  };
  if (settings.siteExceptions && settings.siteExceptions.length) {
    condition.excludedInitiatorDomains = settings.siteExceptions;
  }

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [RULE_ID_HEADERS],
    addRules: [{ id: RULE_ID_HEADERS, priority: 1, action: { type: "modifyHeaders", requestHeaders }, condition }],
  });
}

// --- Блокировка известных антифрод/fingerprint/geo-ip вендоров ---
async function applyTrackerBlockRules(settings) {
  const blockRuleIds = TRACKER_DOMAINS.map((_, i) => RULE_ID_TRACKER_BLOCK_START + i);

  if (!settings.enabled || !settings.blockTrackers) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: blockRuleIds });
    return;
  }

  const addRules = TRACKER_DOMAINS.map((domain, i) => ({
    id: RULE_ID_TRACKER_BLOCK_START + i,
    priority: 1,
    action: { type: "block" },
    condition: {
      requestDomains: [domain],
      resourceTypes: ["xmlhttprequest", "script", "image", "sub_frame", "font", "media", "other"],
    },
  }));

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: blockRuleIds, addRules });
}

async function applyAll(settings) {
  await applyHeaderRules(settings);
  await applyTrackerBlockRules(settings);
}

// --- Статистика сетевой активности вкладки ---
const tabStats = {};
function ensureTabStats(tabId) {
  if (!tabStats[tabId]) tabStats[tabId] = { success: 0, failed: 0, bytes: 0, blocked: [] };
  return tabStats[tabId];
}

chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const s = ensureTabStats(details.tabId);
    s.success++;
    const clHeader = (details.responseHeaders || []).find((h) => h.name.toLowerCase() === "content-length");
    if (clHeader) s.bytes += parseInt(clHeader.value, 10) || 0;
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

chrome.webRequest.onErrorOccurred.addListener(
  (details) => {
    if (details.tabId < 0) return;
    ensureTabStats(details.tabId).failed++;
  },
  { urls: ["<all_urls>"] }
);

// Короткая "вспышка" анимации иконки при блокировке трекера — постоянную
// анимацию иконки в MV3 сделать нельзя (service worker засыпает через
// ~30 сек простоя и убивает любой setInterval), а короткий всплеск на
// реальное событие (событие само будит воркер) работает надёжно.
const PULSE_FRAMES = 6;
const pulsingTabs = new Set();
function pulseIcon(tabId) {
  if (tabId < 0 || pulsingTabs.has(tabId)) return;
  pulsingTabs.add(tabId);
  let i = 0;
  const timer = setInterval(() => {
    chrome.action.setIcon({
      tabId,
      path: {
        16: `icons/pulse/icon16_${i % PULSE_FRAMES}.png`,
        48: `icons/pulse/icon48_${i % PULSE_FRAMES}.png`,
        128: `icons/pulse/icon128_${i % PULSE_FRAMES}.png`,
      },
    }).catch(() => {});
    i++;
    if (i >= PULSE_FRAMES) {
      clearInterval(timer);
      pulsingTabs.delete(tabId);
      chrome.action.setIcon({
        tabId,
        path: { 16: "icons/icon16.png", 48: "icons/icon48.png", 128: "icons/icon128.png" },
      }).catch(() => {});
    }
  }, 70);
}

// Детальный лог того, что именно заблокировала защита от трекеров
// (requestDomains-правила из applyTrackerBlockRules). Доступно только для
// unpacked-расширений — то есть ровно наш случай при загрузке через
// "Загрузить распакованное расширение".
if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    if (info.rule.ruleId < RULE_ID_TRACKER_BLOCK_START) return; // не наши блок-правила
    const tabId = info.request.tabId;
    if (tabId < 0) return;
    const s = ensureTabStats(tabId);
    let hostname = info.request.url;
    try { hostname = new URL(info.request.url).hostname; } catch (e) {}
    s.blocked.unshift({ url: hostname, type: info.request.type, time: Date.now() });
    if (s.blocked.length > 30) s.blocked.length = 30;
    pulseIcon(tabId);
  });
}

chrome.tabs.onRemoved.addListener((tabId) => { delete tabStats[tabId]; });

function safeHostname(url) {
  try { return new URL(url).hostname; } catch (e) { return null; }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "FORCE_REAPPLY") {
    chrome.storage.local.get(DEFAULTS).then((settings) => applyAll(settings));
    return;
  }
  if (msg && msg.type === "GET_TRAFFIC_STATS") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs && tabs[0] ? tabs[0].id : null;
      const s = (tabId !== null && tabStats[tabId]) || { success: 0, failed: 0, bytes: 0, blocked: [] };
      const total = s.success + s.failed;
      const lossPct = total > 0 ? Math.round((s.failed / total) * 100) : 0;
      sendResponse({
        hostname: tabs && tabs[0] && tabs[0].url ? safeHostname(tabs[0].url) : null,
        success: s.success, failed: s.failed, bytes: s.bytes, lossPct,
        blockedCount: s.blocked.length, blocked: s.blocked,
      });
    });
    return true;
  }
});

// --- Инициализация ---
chrome.runtime.onInstalled.addListener(async (details) => {
  await ensureSeed();
  applyAll(await chrome.storage.local.get(DEFAULTS));
  // Автонастройка часового пояса — только при первой установке, один раз,
  // асинхронно и без ожидания (не блокирует applyAll выше). Спуфинг
  // остаётся выключенным по умолчанию — просто нужное значение уже стоит
  // в списке, когда пользователь решит включить его сам.
  if (details.reason === "install") {
    detectTimezoneOnce();
  }
});

async function detectTimezoneOnce() {
  try {
    // Тот же сервис, что и в ручной кнопке попапа — намеренно НЕ входит
    // в TRACKER_DOMAINS выше, иначе наша же блокировка трекеров сломает
    // этот запрос (см. комментарий у списка TRACKER_DOMAINS).
    const res = await fetch("https://ipwho.is/");
    const data = await res.json();
    const tz = data && data.success && data.timezone && data.timezone.id;
    if (tz) {
      await chrome.storage.local.set({ timezone: tz, lastDetectedIpTimezone: tz });
    }
  } catch (e) {
    // Тихо игнорируем — офлайн при установке или сервис недоступен;
    // пользователь всегда может нажать кнопку вручную позже.
  }
}

chrome.runtime.onStartup.addListener(async () => {
  applyAll(await chrome.storage.local.get(DEFAULTS));
});

function generateSeed() {
  return Array.from(crypto.getRandomValues(new Uint8Array(16))).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function ensureSeed() {
  const { fingerprintSeed } = await chrome.storage.local.get({ fingerprintSeed: null });
  if (!fingerprintSeed || fingerprintSeed === "default-seed") {
    await chrome.storage.local.set({ fingerprintSeed: generateSeed() });
  }
}

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== "local") return;
  applyAll(await chrome.storage.local.get(DEFAULTS));
});
