// Выполняется в MAIN world (в контексте самой страницы),
// поэтому имеет доступ к window.navigator, canvas, WebGL и т.п. так же,
// как и скрипты самого сайта.
(function () {
  const currentScript = document.currentScript;
  const ds = currentScript ? currentScript.dataset : {};

  const uaPreset = ds.uaPreset || "windows-chrome";
  const canvasNoiseEnabled = ds.canvasNoise === "true";
  const webglSpoofEnabled = ds.webglSpoof === "true";
  const timezoneSpoofEnabled = ds.timezoneSpoof === "true";
  const timezone = ds.timezone || "Europe/London";
  const webrtcProtectionEnabled = ds.webrtcProtection === "true";
  const hardwareSpoofEnabled = ds.hardwareSpoof === "true";
  const screenSpoofEnabled = ds.screenSpoof === "true";
  const canvasAdaptiveEnabled = ds.canvasAdaptive === "true";
  const fingerprintSeed = ds.fingerprintSeed || "default-seed";

  // --- Детерминированный ГПСЧ (mulberry32), затравленный от seed + домена ---
  // Ключевая идея: шум должен быть ОДИНАКОВЫМ при повторных вызовах на одном
  // и том же сайте в рамках одной "личности" (seed), иначе сам факт того, что
  // toDataURL() возвращает разные хэши при двух вызовах подряд, детектируется
  // антифрод-системами как явный признак спуфинга. При этом шум должен быть
  // РАЗНЫМ между разными сайтами, чтобы сайты не могли связать вас по нему.
  function hashString(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }
  function mulberry32(seed) {
    let a = seed;
    return function () {
      a |= 0; a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const domainSeed = hashString(fingerprintSeed + "::" + location.hostname);
  const rng = mulberry32(domainSeed);
  // отдельный генератор для WebGL-джиттера, чтобы не расходовать последовательность canvas-шума
  const rngWebgl = mulberry32(hashString(fingerprintSeed + "::webgl::" + location.hostname));

  // --- Детектор активного снятия отпечатка ---
  // Идея: обычный сайт трогает canvas/webgl эпизодически (игра, редактор,
  // видео) — там шум должен быть минимальным, чтобы не портить картинку.
  // Но когда за короткое окно происходит несколько разноплановых обращений
  // подряд (canvas + webgl vendor/renderer + audio) — это классическая
  // сигнатура именно fingerprint-скрипта (FingerprintJS и подобные всегда
  // опрашивают несколько источников сразу). В этом случае временно
  // повышаем "агрессию" шума только для текущего окна.
  let fpProbeCount = 0;
  let fpWindowStart = Date.now();
  function registerFpProbe() {
    const now = Date.now();
    if (now - fpWindowStart > 2000) { fpWindowStart = now; fpProbeCount = 0; }
    fpProbeCount++;
    return fpProbeCount >= 3;
  }

  const UA_PRESETS = {
    "windows-chrome": {
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      platform: "Win32", vendor: "Google Inc.",
      appVersion: "5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    },
    "mac-chrome": {
      userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      platform: "MacIntel", vendor: "Google Inc.",
      appVersion: "5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    },
    "linux-chrome": {
      userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      platform: "Linux x86_64", vendor: "Google Inc.",
      appVersion: "5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    },
  };

  const WEBGL_PRESETS = {
    "windows-chrome": { vendor: "Google Inc. (Intel)", renderer: "ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)" },
    "mac-chrome": { vendor: "Google Inc. (Apple)", renderer: "ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)" },
    "linux-chrome": { vendor: "Google Inc. (Mesa)", renderer: "ANGLE (Mesa, Mesa Intel(R) UHD Graphics (CML GT2), OpenGL 4.6)" },
  };

  const uaPresetData = UA_PRESETS[uaPreset] || UA_PRESETS["windows-chrome"];
  const webglPresetData = WEBGL_PRESETS[uaPreset] || WEBGL_PRESETS["windows-chrome"];

  // --- Вариативность UA в разумных пределах ---
  // Абсолютно одинаковый UA у всех пользователей расширения — сам по себе
  // узнаваемый паттерн. Подставляем один из нескольких валидных build-номеров
  // Chrome вместо фиксированного 126.0.0.0, стабильно для домена.
  const CHROME_BUILDS = ["126.0.6478.126", "126.0.6478.182", "127.0.6533.72", "125.0.6422.141", "126.0.6478.61"];
  const buildVariant = CHROME_BUILDS[Math.floor(rng() * CHROME_BUILDS.length)];
  const uaFull = uaPresetData.userAgent.replace("126.0.0.0", buildVariant);
  const appVersionFull = uaPresetData.appVersion.replace("126.0.0.0", buildVariant);

  function defineProp(obj, prop, value) {
    try {
      Object.defineProperty(obj, prop, {
        get() { return value; },
        configurable: true,
      });
    } catch (e) {}
  }

  // --- Подмена navigator.* (UA/платформа привязаны к выбранному профилю) ---
  defineProp(navigator, "userAgent", uaFull);
  defineProp(navigator, "platform", uaPresetData.platform);
  defineProp(navigator, "vendor", uaPresetData.vendor);
  defineProp(navigator, "appVersion", appVersionFull);
  if (navigator.userAgentData) defineProp(navigator, "userAgentData", undefined);

  // --- Подмена аппаратных характеристик (несколько слоёв) ---
  if (hardwareSpoofEnabled) {
    const coresOptions = [4, 6, 8, 12, 16];
    const memOptions = [4, 8, 16];
    defineProp(navigator, "hardwareConcurrency", coresOptions[Math.floor(rng() * coresOptions.length)]);
    if ("deviceMemory" in navigator) {
      defineProp(navigator, "deviceMemory", memOptions[Math.floor(rng() * memOptions.length)]);
    }
    // devicePixelRatio — второстепенный, но используемый вектор (retina vs обычный экран)
    const dprOptions = [1, 1.25, 1.5, 2];
    defineProp(window, "devicePixelRatio", dprOptions[Math.floor(rng() * dprOptions.length)]);
    // colorDepth почти всегда 24 у реальных пользователей — нормализуем на случай,
    // если у ОС нестандартное значение, которое выделяло бы вас из толпы
    defineProp(screen, "colorDepth", 24);
    defineProp(screen, "pixelDepth", 24);
  }

  // --- Подмена разрешения экрана (отдельный тумблер, безопасный по вёрстке) ---
  // Трогаем ТОЛЬКО screen.width/height/availWidth/availHeight — это то, что
  // читают fingerprint-скрипты. window.innerWidth/innerHeight и
  // outerWidth/outerHeight НЕ трогаем: именно они определяют реальную
  // раскладку страницы (медиа-запросы, JS-логику адаптива), и их подмена
  // рвёт вёрстку сайтов. Так разрешение экрана меняется "для фингерпринта",
  // а страница продолжает рендериться под настоящий размер окна.
  if (screenSpoofEnabled) {
    const screenPresets = [
      { w: 1920, h: 1080 }, { w: 1366, h: 768 }, { w: 1536, h: 864 },
      { w: 2560, h: 1440 }, { w: 1440, h: 900 },
    ];
    const preset = screenPresets[Math.floor(rng() * screenPresets.length)];
    defineProp(screen, "width", preset.w);
    defineProp(screen, "height", preset.h);
    defineProp(screen, "availWidth", preset.w);
    defineProp(screen, "availHeight", preset.h - 40);
  }

  // --- Подмена часового пояса ---
  // Раньше offset брался из жёсткой таблицы (не учитывал переход на летнее
  // время и был ограничен 5 зонами). Теперь offset вычисляется динамически
  // через нативный Intl ДО того, как мы его переопределим — точно для любой
  // IANA-зоны и с корректным учётом текущего DST.
  if (timezoneSpoofEnabled) {
    const NativeIntlDateTimeFormat = Intl.DateTimeFormat; // ссылка на оригинал, до патчей

    function computeOffsetMinutes(tz, date) {
      try {
        const dtf = new NativeIntlDateTimeFormat("en-US", {
          timeZone: tz, hour12: false,
          year: "numeric", month: "2-digit", day: "2-digit",
          hour: "2-digit", minute: "2-digit", second: "2-digit",
        });
        const parts = {};
        dtf.formatToParts(date).forEach((p) => { parts[p.type] = p.value; });
        const hour = parts.hour === "24" ? "00" : parts.hour;
        const asUTC = Date.UTC(
          Number(parts.year), Number(parts.month) - 1, Number(parts.day),
          Number(hour), Number(parts.minute), Number(parts.second)
        );
        // Насколько "стенное время" в этой зоне опережает реальный UTC-момент
        return Math.round((date.getTime() - asUTC) / 60000);
      } catch (e) {
        return 0;
      }
    }

    const offsetMinutes = computeOffsetMinutes(timezone, new Date());

    const origDateTimeFormat = Intl.DateTimeFormat;
    const origResolvedOptions = origDateTimeFormat.prototype.resolvedOptions;
    Intl.DateTimeFormat = new Proxy(origDateTimeFormat, {
      construct(target, args) {
        if (args.length === 0) args = [undefined, {}];
        if (!args[1]) args[1] = {};
        if (!args[1].timeZone) args[1].timeZone = timezone;
        return Reflect.construct(target, args);
      },
    });
    Intl.DateTimeFormat.prototype = origDateTimeFormat.prototype;
    origDateTimeFormat.prototype.resolvedOptions = function (...args) {
      const result = origResolvedOptions.apply(this, args);
      result.timeZone = timezone;
      return result;
    };

    function shifted(date) { return new Date(date.getTime() - offsetMinutes * 60000); }
    const proto = Date.prototype;
    proto.getTimezoneOffset = function () { return offsetMinutes; };
    proto.getFullYear = function () { return shifted(this).getUTCFullYear(); };
    proto.getMonth = function () { return shifted(this).getUTCMonth(); };
    proto.getDate = function () { return shifted(this).getUTCDate(); };
    proto.getDay = function () { return shifted(this).getUTCDay(); };
    proto.getHours = function () { return shifted(this).getUTCHours(); };
    proto.getMinutes = function () { return shifted(this).getUTCMinutes(); };
    proto.getSeconds = function () { return shifted(this).getUTCSeconds(); };
    proto.getMilliseconds = function () { return shifted(this).getUTCMilliseconds(); };

    const WEEKDAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    function pad(n) { return String(n).padStart(2, "0"); }
    proto.toDateString = function () {
      const d = shifted(this);
      return `${WEEKDAYS[d.getUTCDay()]} ${MONTHS[d.getUTCMonth()]} ${pad(d.getUTCDate())} ${d.getUTCFullYear()}`;
    };
    proto.toTimeString = function () {
      const d = shifted(this);
      const tzLabel = timezone.split("/").pop().replace("_", " ");
      return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())} GMT+0000 (${tzLabel})`;
    };
    proto.toString = function () { return `${this.toDateString()} ${this.toTimeString()}`; };
    proto.toLocaleDateString = function (locales, opts) {
      return new Intl.DateTimeFormat(locales, { ...opts, timeZone: timezone }).format(this);
    };
    proto.toLocaleTimeString = function (locales, opts) {
      return new Intl.DateTimeFormat(locales, { ...(opts || {}), timeZone: timezone, hour: "numeric", minute: "numeric", second: "numeric" }).format(this);
    };
    proto.toLocaleString = function (locales, opts) {
      return new Intl.DateTimeFormat(locales, { ...(opts || {}), timeZone: timezone }).format(this);
    };
  }

  // --- Подмена WebGL vendor/renderer + лёгкий детерминированный джиттер лимитов ---
  // Работает "в реальном времени" — перехватывает каждый вызов getParameter()
  // на лету, а не подменяет один раз при загрузке.
  if (webglSpoofEnabled) {
    // Небольшой, но стабильный на домен разброс "железных" лимитов, чтобы
    // отпечаток не совпадал 1-в-1 с типовым пресетом (который сам по себе
    // тоже уникален, если все используют один и тот же).
    const jitterCache = new Map();
    function jitteredLimit(base, param) {
      if (!jitterCache.has(param)) {
        const delta = Math.floor((rngWebgl() - 0.5) * (base * 0.02));
        jitterCache.set(param, base + delta);
      }
      return jitterCache.get(param);
    }

    const spoofGetParameter = (proto) => {
      const orig = proto.getParameter;
      proto.getParameter = function (param) {
        if (param === 37445 || param === 37446) registerFpProbe(); // запрос vendor/renderer — сильный сигнал fingerprint-скрипта
        if (param === 37445) return webglPresetData.vendor;   // UNMASKED_VENDOR_WEBGL
        if (param === 37446) return webglPresetData.renderer; // UNMASKED_RENDERER_WEBGL
        if (param === 3379) return jitteredLimit(16384, param); // MAX_TEXTURE_SIZE
        if (param === 34024) return jitteredLimit(16384, param); // MAX_RENDERBUFFER_SIZE
        return orig.apply(this, arguments);
      };
    };
    if (window.WebGLRenderingContext) spoofGetParameter(WebGLRenderingContext.prototype);
    if (window.WebGL2RenderingContext) spoofGetParameter(WebGL2RenderingContext.prototype);
  }

  // --- Защита от утечки локального/реального IP через WebRTC ---
  if (webrtcProtectionEnabled && window.RTCPeerConnection) {
    const OrigRTCPeerConnection = window.RTCPeerConnection;
    function filterSDP(sdp) {
      if (!sdp) return sdp;
      return sdp.split("\n").filter((line) => {
        if (line.startsWith("a=candidate")) return line.includes(" typ relay ");
        return true;
      }).join("\n");
    }

    class ProtectedRTCPeerConnection extends OrigRTCPeerConnection {
      async createOffer(...args) {
        if (typeof args[0] === "function") return super.createOffer(...args);
        const offer = await super.createOffer(...args);
        if (offer && offer.sdp) offer.sdp = filterSDP(offer.sdp);
        return offer;
      }
      async createAnswer(...args) {
        if (typeof args[0] === "function") return super.createAnswer(...args);
        const answer = await super.createAnswer(...args);
        if (answer && answer.sdp) answer.sdp = filterSDP(answer.sdp);
        return answer;
      }
      async setLocalDescription(desc, ...args) {
        if (desc && desc.sdp) desc = { ...desc, sdp: filterSDP(desc.sdp) };
        return super.setLocalDescription(desc, ...args);
      }
      set onicecandidate(handler) {
        super.onicecandidate = (event) => {
          if (!event.candidate || (event.candidate.candidate && event.candidate.candidate.includes(" typ relay "))) {
            handler(event);
          }
        };
      }
      get onicecandidate() { return super.onicecandidate; }
    }

    window.RTCPeerConnection = ProtectedRTCPeerConnection;
    if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = ProtectedRTCPeerConnection;
  }

  // --- Стабильный (seeded) шум в Canvas / Audio fingerprint, с адаптивной агрессией ---
  if (canvasNoiseEnabled) {
    function noiseProbability() {
      if (!canvasAdaptiveEnabled) return 0.02; // фиксированный мягкий уровень
      const aggressive = registerFpProbe();
      return aggressive ? 0.06 : 0.012; // мягче на обычных сайтах, жёстче при явном fingerprinting-паттерне
    }

    const noisify = (canvas, origFn, args) => {
      const ctx = canvas.getContext("2d");
      if (!ctx) return origFn.apply(canvas, args);
      const { width, height } = canvas;
      if (width === 0 || height === 0) return origFn.apply(canvas, args);

      const imageData = ctx.getImageData(0, 0, width, height);
      const data = imageData.data;
      const p = noiseProbability();
      // rng() детерминирован по домену — один и тот же canvas на одном сайте
      // всегда даёт один и тот же хэш в рамках текущего "отпечатка" (seed),
      // но разный на другом сайте и разный после смены отпечатка в попапе.
      for (let i = 0; i < data.length; i += 4) {
        if (rng() < p) {
          data[i] ^= 1; data[i + 1] ^= 1; data[i + 2] ^= 1;
        }
      }
      ctx.putImageData(imageData, 0, 0);
      return origFn.apply(canvas, args);
    };

    const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function (...args) {
      registerFpProbe();
      return noisify(this, origToDataURL, args);
    };

    const origToBlob = HTMLCanvasElement.prototype.toBlob;
    HTMLCanvasElement.prototype.toBlob = function (...args) {
      registerFpProbe();
      noisify(this, () => {}, []);
      return origToBlob.apply(this, args);
    };

    const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
    CanvasRenderingContext2D.prototype.getImageData = function (...args) {
      const imageData = origGetImageData.apply(this, args);
      const p = noiseProbability();
      for (let i = 0; i < imageData.data.length; i += 4) {
        if (rng() < p) imageData.data[i] ^= 1;
      }
      return imageData;
    };

    if (window.AudioBuffer) {
      const origGetChannelData = AudioBuffer.prototype.getChannelData;
      AudioBuffer.prototype.getChannelData = function (...args) {
        registerFpProbe();
        const data = origGetChannelData.apply(this, args);
        // Шум на уровне долей микровольта — не влияет на слышимое воспроизведение,
        // но ломает хэш AudioContext-фингерпринта
        for (let i = 0; i < data.length; i += 100) {
          data[i] = data[i] + (rng() * 0.0000001 - 0.00000005);
        }
        return data;
      };
    }
  }
})();
