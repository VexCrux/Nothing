// Внедряет inject.js в MAIN world страницы как можно раньше,
// чтобы навигационные свойства были переопределены до того,
// как сайт успеет их прочитать.
(function () {
  const DEFAULTS = {
    enabled: true,
    uaPreset: "windows-chrome",
    canvasNoise: true,
    canvasAdaptive: true,
    webglSpoof: true,
    timezoneSpoof: false,
    timezone: "Europe/London",
    webrtcProtection: true,
    webrtcWhitelist: [],
    hardwareSpoof: true,
    screenSpoof: false,
    fingerprintSeed: "default-seed",
    siteExceptions: [],
  };

  chrome.storage.local.get(DEFAULTS, (settings) => {
    if (!settings.enabled) return;

    const hostname = location.hostname;
    const isExcepted = (settings.siteExceptions || []).some(
      (h) => hostname === h || hostname.endsWith("." + h)
    );
    if (isExcepted) return;

    const isWebrtcWhitelisted = (settings.webrtcWhitelist || []).some(
      (h) => hostname === h || hostname.endsWith("." + h)
    );

    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("inject.js");
    script.dataset.uaPreset = settings.uaPreset;
    script.dataset.canvasNoise = String(settings.canvasNoise);
    script.dataset.canvasAdaptive = String(settings.canvasAdaptive);
    script.dataset.webglSpoof = String(settings.webglSpoof);
    script.dataset.timezoneSpoof = String(settings.timezoneSpoof);
    script.dataset.timezone = settings.timezone;
    // Если сайт в белом списке WebRTC (видеозвонки и т.п.) — не трогаем WebRTC,
    // чтобы не сломать соединение, даже если защита включена глобально
    script.dataset.webrtcProtection = String(settings.webrtcProtection && !isWebrtcWhitelisted);
    script.dataset.hardwareSpoof = String(settings.hardwareSpoof);
    script.dataset.screenSpoof = String(settings.screenSpoof);
    script.dataset.fingerprintSeed = settings.fingerprintSeed;

    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();
  });
})();
